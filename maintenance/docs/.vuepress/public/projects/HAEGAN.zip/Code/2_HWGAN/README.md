# Step 2: Train HWGAN

## Train HWGAN with the hyperbolic embeddings

The configuration file is located in `../config.py`.

```
python HWGAN.py
```

## Sample from HWGAN and Decode

The configuration file is located in `../config.py`.

```
python Sample.py
```

## Test the samples

```
python morse_test.py
```